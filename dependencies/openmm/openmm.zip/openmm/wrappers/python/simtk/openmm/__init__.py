from openmm import *
from . import app

import logging
logging.getLogger().warning("Warning: importing 'simtk.openmm' is deprecated.  Import 'openmm' instead.")